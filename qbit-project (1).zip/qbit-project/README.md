# Q-BIT Learner Model — Setup

## Files
- `login.html`        — Supabase auth (sign up / log in / log out)
- `quantum_app.html`  — the app itself. Requires login; redirects to
                          login.html if nobody's signed in.
- `api.py`            — Flask API wrapping learner_model.py
- `learner_model.py`  — concept graph, diagnostic scoring, mastery model,
                          adaptive rules
- `quantum_tutor_quiz_dataset.csv` — question bank (must stay next to
                          api.py / learner_model.py)

## How the pieces connect
- `login.html` and `quantum_app.html` share the same Supabase project,
  so a session created on the login page carries over automatically.
- After logging in, quantum_app.html gets the real Supabase user (their
  UUID + email) and uses that UUID as the user_id sent to the learner
  model API — so mastery/history is tied to the actual account, not a
  random per-browser guest id.
- Logging out on quantum_app.html signs out of Supabase and sends you
  back to login.html.

## The one step left (whenever you're ready)

    pip install flask
    python3 api.py

That starts the server at http://localhost:5000. Leave that terminal open.

Then serve the folder (don't just double-click — auth redirects need a
real origin, not file://):

    python3 -m http.server 8000

Visit http://localhost:8000/login.html, sign up / log in, and you'll land
on quantum_app.html automatically.

## Without the API server running

The app still works fully — quizzes save to Supabase, login/logout works.
You just won't see the "Next: ..." mastery/recommendation line, since that
comes from the API. No errors, no broken UI — check the browser console if
you want to confirm it's not reaching the server.

## Deploying later (for judges on other devices)

Deploy api.py (with learner_model.py + the CSV alongside it) to Render,
Railway, or PythonAnywhere, then change this line near the top of
quantum_app.html's <script> block:

    const LEARNER_API_URL = "http://localhost:5000";

to your deployed URL.
